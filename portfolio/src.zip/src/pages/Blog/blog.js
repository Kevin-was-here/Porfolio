import './blog.css'

function Blog() {

    return (
        <div className="blog">
        <h1>Blog</h1>
        </div>
    )
}

export default Blog