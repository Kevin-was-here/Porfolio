import './home.css'
import React from 'react'

const Home = () => {

    console.log("Home page rendered");

    return (
        <div>
            <h1>Welcome to GeeksforGeeks</h1>
        </div>
    );
};
 
export default Home;