import './contact.css'

function Contact() {

    return (
        <div className="contact">
        <h1>Contact</h1>
        </div>
    )
}

export default Contact